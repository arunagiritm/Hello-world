cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/cordova-plugin-globalization/www/GlobalizationError.js",
        "id": "cordova-plugin-globalization.GlobalizationError",
        "pluginId": "cordova-plugin-globalization",
        "clobbers": [
            "window.GlobalizationError"
        ]
    },
    {
        "file": "plugins/cordova-plugin-globalization/www/globalization.js",
        "id": "cordova-plugin-globalization.globalization",
        "pluginId": "cordova-plugin-globalization",
        "clobbers": [
            "navigator.globalization"
        ]
    },
    {
        "file": "plugins/cordova-plugin-inappbrowser/www/inappbrowser.js",
        "id": "cordova-plugin-inappbrowser.inappbrowser",
        "pluginId": "cordova-plugin-inappbrowser",
        "clobbers": [
            "cordova.InAppBrowser.open",
            "window.open"
        ]
    },
    {
        "file": "plugins/cordova-plugin-actionsheet/www/ActionSheet.js",
        "id": "cordova-plugin-actionsheet.ActionSheet",
        "pluginId": "cordova-plugin-actionsheet",
        "clobbers": [
            "window.plugins.actionsheet"
        ]
    },
    {
        "file": "plugins/cordova-plugin-device/www/device.js",
        "id": "cordova-plugin-device.device",
        "pluginId": "cordova-plugin-device",
        "clobbers": [
            "device"
        ]
    },
    {
        "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
        "id": "cordova-plugin-splashscreen.SplashScreen",
        "pluginId": "cordova-plugin-splashscreen",
        "clobbers": [
            "navigator.splashscreen"
        ]
    },
    {
        "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
        "id": "cordova-plugin-statusbar.statusbar",
        "pluginId": "cordova-plugin-statusbar",
        "clobbers": [
            "window.StatusBar"
        ]
    },
    {
        "file": "plugins/ionic-plugin-keyboard/www/android/keyboard.js",
        "id": "ionic-plugin-keyboard.keyboard",
        "pluginId": "ionic-plugin-keyboard",
        "clobbers": [
            "cordova.plugins.Keyboard"
        ],
        "runs": true
    },
    {
        "file": "plugins/cordova-plugin-network-information/www/network.js",
        "id": "cordova-plugin-network-information.network",
        "pluginId": "cordova-plugin-network-information",
        "clobbers": [
            "navigator.connection",
            "navigator.network.connection"
        ]
    },
    {
        "file": "plugins/cordova-plugin-network-information/www/Connection.js",
        "id": "cordova-plugin-network-information.Connection",
        "pluginId": "cordova-plugin-network-information",
        "clobbers": [
            "Connection"
        ]
    },
    {
        "file": "plugins/com.citi.mobile.cdt.plugins.cmamt/www/CMAMT.js",
        "id": "com.citi.mobile.cdt.plugins.cmamt.CMAMT",
        "pluginId": "com.citi.mobile.cdt.plugins.cmamt",
        "clobbers": [
            "CMAMT"
        ]
    },
    {
        "file": "plugins/nl.x-services.plugins.sslcertificatechecker/www/SSLCertificateChecker.js",
        "id": "nl.x-services.plugins.sslcertificatechecker.SSLCertificateChecker",
        "pluginId": "nl.x-services.plugins.sslcertificatechecker",
        "clobbers": [
            "window.plugins.sslCertificateChecker"
        ]
    },
    {
        "file": "plugins/cordova-plugin-app-version/www/AppVersionPlugin.js",
        "id": "cordova-plugin-app-version.AppVersionPlugin",
        "pluginId": "cordova-plugin-app-version",
        "clobbers": [
            "cordova.getAppVersion"
        ]
    },
    {
        "file": "plugins/cordova-plugin-dialogs/www/notification.js",
        "id": "cordova-plugin-dialogs.notification",
        "pluginId": "cordova-plugin-dialogs",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "file": "plugins/cordova-plugin-dialogs/www/android/notification.js",
        "id": "cordova-plugin-dialogs.notification_android",
        "pluginId": "cordova-plugin-dialogs",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "file": "plugins/cordova-plugin-decimal-keyboard/www/decimal-keyboard.js",
        "id": "cordova-plugin-decimal-keyboard.decimalKeyboard",
        "pluginId": "cordova-plugin-decimal-keyboard",
        "clobbers": [
            "window.DecimalKeyboard"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-globalization": "1.0.5",
    "cordova-plugin-inappbrowser": "1.6.1",
    "cordova-plugin-actionsheet": "2.3.3",
    "cordova-plugin-device": "1.1.4",
    "cordova-plugin-splashscreen": "4.0.1",
    "cordova-plugin-statusbar": "2.2.1",
    "ionic-plugin-keyboard": "2.2.1",
    "cordova-plugin-network-information": "1.3.2",
    "com.citi.mobile.cdt.plugins.alert": "1.0.0",
    "com.citi.mobile.cdt.plugins.cmamt": "0.0.1",
    "nl.x-services.plugins.sslcertificatechecker": "3.5.0",
    "com.citi.mobile.cdt.util.cordovalogger": "1.0.0",
    "cordova-plugin-app-version": "0.1.9",
    "cordova-plugin-dialogs": "1.3.2",
    "cordova-plugin-disable-bitcode": "1.3.2",
    "cordova-plugin-privacyscreen": "0.3.1",
    "cordova-plugin-whitelist": "1.3.2",
    "cordova-plugin-decimal-keyboard": "1.0"
}
// BOTTOM OF METADATA
});