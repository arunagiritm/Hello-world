var fs = require('fs');
var path = require('path');
var modulePath =path.join(__dirname,"/node_modules");
var spawn = require('child_process').spawn;

//list of commands to be executed.
var packages = [
	  {
		  command: "npm.cmd",
		  args: ["install", "-g", "webpack"]
	  },
	  {
		  command: "npm.cmd",
		  args: ["install", "-g", "webpack-dev-server"]
	  },
	   {
		  command: "npm.cmd",
		  args: ["install", "-g", "typescript"]
	  },
	   {
		  command: "npm.cmd",
		  args: ["install", "-g", "karma"]
	  }
];
//function to execute the shell commands with arguments
function run_cmd(cmd, args) {
    var child = spawn(cmd, args);
	console.log(` ${args.join( )}`);
    child.stdout.on('data', function (buffer) { console.log(buffer.toString()) });
    child.stdout.on('end', function(){console.log(`completed executing ${cmd} ${args.join( )}`)});
	child.stdout.on('error', function(err){console.log(`error occured ${err}` )});
}

//check for node_moudles folder availability, execute npm install if not found

// if (!fs.existsSync(modulePath)) {
	// var depInstall = {
		  // command: "npm.cmd",
		  // args: ["install"]
	  // }
	  
	  // packages.unshift(depInstall);
// }

//loop through the package and execute
for (package in packages){
	var cmd = packages[package].command;
	var args =  packages[package].args;
	var runcmd = new run_cmd(cmd,args);
	
}
