cordova.define("com.citi.mobile.cdt.plugins.cmamt.CMAMT", function(require, exports, module) { var exec = require('cordova/exec')
function CMAMT(){
    var that=this;
}
CMAMT.prototype.getInfo = function(successCallback, errorCallback){
    exec(successCallback, errorCallback, 'CMAMT', 'getCMAMTInfo',[]);
}
module.exports = new CMAMT();
});
