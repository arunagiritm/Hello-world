var head = document.getElementsByTagName('body')[0];
var script = document.createElement('script');
script.src = './cordova.js';
head.appendChild(script);
