import { AppTitleBarController } from './modules/common/directives/app-title-bar/app-title-bar.controller';
import { AppMenu } from './modules/common/directives/app-menu/app-menu';
import { AppDashboardController } from './modules/authorized/dashboard/contents/app-dashboard.controller';
import { AppHeaderService } from './modules/common/directives/app-title-bar/app-header.service';
import { AppErrorCodes } from './config/services/app-error-codes';
import { SessionModel } from './modules/common/models/session-model';
import { HttpInteraction } from './config/services/http-interaction';
import { DashboardStructure } from './modules/authorized/dashboard/structure/dashboard-structure';
import { AppService } from './config/services/app-service';
import { AppUtils } from './modules/common/services/app-utils';
import * as angular from "angular";
import "./referencelibs";
import "./styles";
import { AppLanguageCodes } from './config/services/app-language-codes';
import { appSettings } from './config/settings/app-settings';
import { omnicfw } from './modules/extend/omnicfw/app-omnicfw';
import { appRoutes } from "./config/routes/app-cdm-routes";
import "./modules/extend/device/app-device"
import "./modules/extend/omnicfw/app-omnicfw"
import "./preload";
import "./assets/css/animate.css";
import { AppTealeafSession } from "./modules/common/services/app-tealeaf-session";
import { DynamicCodeStructure } from "./modules/unauthorized/dynamic-code/structure/dynamic-code-structure";
import { AppDynamicCodeController } from "./modules/unauthorized/dynamic-code/contents/app-dynamic-code";
import { AppDynamicCode } from "./modules/unauthorized/dynamic-code/contents/app-dynamic-code";
import { LoginStructure } from "./modules/unauthorized/login/structure/login-structure";
import { AppTitleBar } from "./modules/common/directives/app-title-bar/app-title-bar";
import { APPEnums } from "./config/services/app-enum";
import { AppCore } from "./modules/common/services/app-core";
import  './modules/unauthorized/login/contents/app-login';
import { AppDialog, AppDialogService } from "./modules/common/directives/app-dialog/app-dialog"
import { AppDashboardComponent } from './modules/authorized/dashboard/contents/app-dashboard';
import { AppLoginController } from "./modules/unauthorized/login/contents/app-login.controller";
import { AppLogin } from "./modules/unauthorized/login/contents/app-login";

declare var process;

if(process.env.ENV == 'MOBILE'){
    require('../load_script.js');
}

    let urlRouterProvider;
    let stateProvider;
    export let app = angular.module('app', ['ui.router', 'ngAnimate', 'omniCfw', 'ActivityMonitor', 'app.device', 'app.omnicfw']);
    app.config(AppConfig)
        .run(AppRun)
        .service('AppUtils', AppUtils)
        .service("AppErrorCodes", AppErrorCodes)
        .service('AppTealeafSession', AppTealeafSession)
        .service('AppHeader', AppHeaderService)
        .service('AppService', AppService)
        .service("HttpInteraction", HttpInteraction)
        .service("SessionModel", SessionModel)
        .service("APPEnums", APPEnums)
        .service("appEnums", APPEnums)
        .service("AppCore", AppCore)
        .service("AppDialogService", AppDialogService)
        .service("AppLanguageCodes", AppLanguageCodes)
        .service('AppDashboardController', AppDashboardController)
        .controller('DynamicCodeStructure', DynamicCodeStructure)
        .controller('LoginStructure', LoginStructure)
        .controller("DashboardStructure", DashboardStructure)
        .controller("AppDynamicCodeController", AppDynamicCodeController)
        .controller("AppLoginController", AppLoginController)
        .directive("appDynamicCode", AppDynamicCode)
        .directive("appLogin", AppLogin)
        .directive("appTitleBar", AppTitleBar)
        .directive("appMenu", AppMenu)
        .directive('appDialog', AppDialog)
        .component('appDashboard', AppDashboardComponent);


    deviceReady();

    AppConfig.$inject = ['$locationProvider', '$httpProvider', '$controllerProvider', '$compileProvider', '$provide', '$filterProvider', '$stateProvider', '$urlRouterProvider'];

    function AppConfig($locationProvider, $httpProvider, $controllerProvider, $compileProvider, $provide, $filterProvider, $stateProvider, $urlRouterProvider) {
        app.controller = $controllerProvider.register;
        app.directive = $compileProvider.directive;
        app.filter = $filterProvider.register;
        app.service = $provide.service;
        // app.routes = appRoutes;
        // app.provide = $provide;
        // app.stateProvider = $stateProvider;
        // app.urlRouterProvider = $urlRouterProvider;
        stateProvider = $stateProvider;
        urlRouterProvider = $urlRouterProvider;
    }

    AppRun.$inject = [
        '$state',
        '$injector',
        '$cordovaKeyboard',
        'cmbLocaliseService',
        'OmniCfwCoreService',
        'OmniCfwCommunicationService',
        'OmniCfwDeviceService',
        'AppDeviceService',
        'validator',
        'inlineElementModifier',
        '$cordovaDialogs'

    ];

    function AppRun(
        $state,
        $injector,
        $cordovaKeyboard,
        cmbLocaliseService,
        OmniCfwCoreService,
        OmniCfwCommunicationService,
        OmniCfwDeviceService,
        AppDeviceService,
        validator,
        inlineElementModifier,
        $cordovaDialogs

    ) {

        var config = {
            path: "libs/omnicfw",
            routeInfo: {
                defaultRoute: "/login",
                defaultState: "login",
                stateProvider: stateProvider,
                urlRouteProvider: urlRouterProvider,
                routes: appRoutes,
                defaultErrorRoute: "/errorPage",
                defaultErrorState: "errorPage"
            },
            mock: appSettings.omnicfwConfig
        };

        var filesToPreload = [
            'app/modules/common/models/session-model',
            'app/modules/common/services/app-core',
            'app/config/services/app-language-codes',
            'app/modules/common/directives/app-title-bar/app-title-bar',
            'app/modules/common/directives/app-menu/app-menu',
            'app/modules/common/directives/app-dialog/app-dialog',
        ];

        var bootstrap = function () {
            AppDeviceService.getLanguage().then(function (language) {
                // require(filesToPreload, function () {
                var AppCore = $injector.get('AppCore');
                AppCore.init(language).then(function () {
                    OmniCfwCoreService.init(config);
                    AppDeviceService.bootstrap();
                    $state.go(config.routeInfo.defaultState);
                });
                // });
            });

        }
        var reject = function (response) {
            routeToErrorPage(response);
        };
        //gotoErrorPage
        var routeToErrorPage = function (errorCode, showLoginButton?, showAppStore?) {
            OmniCfwCoreService.init(config); // Load the error page
            AppDeviceService.bootstrap();
            $state.go(config.routeInfo.defaultErrorState, {
                'errorCode': errorCode,
                'showLogin': showLoginButton,
                'showAppStore': showAppStore
            });
        };

        AppDeviceService.canContinue().then(bootstrap, reject);

        validator.setInvalidElementStyling(false);// To supress the default validator inline styling
        validator.registerDomModifier(inlineElementModifier.key, inlineElementModifier);
        validator.setDefaultElementModifier(inlineElementModifier.key);//wallElementModifier


    }
    function bootstrapAngular() {
        if (!(window.location.hash.toLowerCase() == "" || window.location.hash.toLowerCase() == "#/login")) {
            window.location.href = "";
        } else {
            angular.bootstrap(document, ['app']);
        }
    }

    function deviceReady() {
        if (document.URL.indexOf('http://') === -1 && document.URL.indexOf('https://') === -1) {
            //in app
            document.addEventListener("deviceready", function () {
                bootstrapAngular();
            }, true);
        }
        else {
            //in desktop
            bootstrapAngular();
        }
    }
