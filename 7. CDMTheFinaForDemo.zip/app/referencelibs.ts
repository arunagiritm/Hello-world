import "../libs/3rdparty/angular/angular-ui-router";
import "../libs/3rdparty/angular/angular-animate";
import "../libs/omniCfw";
import "../libs/3rdparty/angular/ng-cordova";
import "../libs/3rdparty/angular/ui-bootstrap-tpls";
import "../libs/3rdparty/angular/angular-ui-tab-scroll";
import "../libs/uifw/UIFW";
import "../libs/uifw/uifw.grid.package";
import "../libs/uifw/ngUIFW";
import "./assets/css/animate.css";  
import "../libs/3rdparty/spin";
import "../libs/3rdparty/angular/angular-activity-monitor";
import "../libs/3rdparty/ionicons/css/ionicons.css";  
import "../libs/3rdparty/fastclick";

    
