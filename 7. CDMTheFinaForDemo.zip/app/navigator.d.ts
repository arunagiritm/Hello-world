interface Navigator{
    language:string,
    languages: string[],
    userLanguage:string
}