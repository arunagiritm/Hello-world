import * as angular from "angular";

    'use strict';

    export class AppDashboardController {
        static $inject: Array<string> = ['$state'];
        constructor(private $state:ng.ui.IState) {}

    }

    // angular
    //     .module('app')
    //     .controller('AppDashboardController', AppDashboardController);
