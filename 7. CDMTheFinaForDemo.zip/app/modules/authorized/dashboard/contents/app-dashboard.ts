import { AppDashboardController } from './app-dashboard.controller';
import * as angular from 'angular';
import { DashboardStructure } from './../structure/dashboard-structure';
import { APPEnums } from './../../../../config/services/app-enum';
import { } from './AppDashboardController'

'use strict';
export class AppDashboardComponent implements ng.IComponentOptions {
    constructor(
        public templateUrl: string,
        public controller: string,
        public controllerAs: string
    ) {
        this.templateUrl = './app-DashboardStructure.html';
        this.controller = 'AppDashboardController';
        this.controllerAs=  'dashboard';
    }



}

// angular.module('app')
//     .component('appDashboard', AppDashboardComponent);
