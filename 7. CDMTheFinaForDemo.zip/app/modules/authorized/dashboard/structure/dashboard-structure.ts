export class DashboardStructure  {
    'use strict';

}
