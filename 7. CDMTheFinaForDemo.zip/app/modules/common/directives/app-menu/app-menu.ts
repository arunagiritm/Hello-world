
 const template: any =  require('./app-menu.html');
// AppMenu.$inject = ['OmniCfwDrawerService', '$timeout', 'APPEnums'];
export function AppMenu(OmniCfwDrawerService, $timeout, APPEnums) {
    return {
        restrict: 'E',
        scope: {},
        // templateUrl: APPEnums.TEMPLATE_URL.MENU,
        // template: require('./app-menu.html'),
        template,
        controller: 'AppMenuController',
        link: AppMenuLink,
        bindToController: true,
        controllerAs: 'menu'
    };

    function AppMenuLink(s, e, a) {
        var onResume = function () {
            $timeout(function () {
                OmniCfwDrawerService.hideDrawer();
            }, 0);
        }
        $(document).on("resume", onResume);

        s.$watch(function () { return OmniCfwDrawerService.getDrawerStatus(); }, function (n, o) {
            if (n != o) {
                s.visible = n;
                if (n === true) {
                    $(e.find('.backdrop-wrapper')).on('touchmove', function (ev) { ev.preventDefault(); });
                    $(e.find('.leftmenu')).on('touchmove', function (ev) { ev.preventDefault(); });
                } else {
                    $(e.find('.backdrop-wrapper')).off('touchmove');
                    $(e.find('.leftmenu')).off('touchmove');
                }
            }

        }, true);
    }
}

AppMenuController.$inject = ['$scope', '$state', 'OmniCfwDrawerService', 'SessionModel'];
export function AppMenuController($scope, $state, OmniCfwDrawerService, SessionModel) {
    // this.dictionary = Cmb.UI.Localisation.CDM;
    // console.log(this.dictionary);
    var logout = function () {
        SessionModel.logout();
        $state.go('login');
    };
    $scope.logout = function () {
        OmniCfwDrawerService.hideDrawer();
        logout();
    };


}
// app.directive('appMenu', AppMenu);