import { AppHeaderService } from './app-header.service';
import * as angular from 'angular';
'use strict';

export class AppTitleBarController {
    title = this.appHeaderService.getPageInfo().title;
    static $inject = ['$scope', 'OmniCfwDrawerService', 'AppHeaderService'];
    constructor(public $scope: ng.IScope, private OmniCfwDrawerService, private appHeaderService: AppHeaderService) {
        this.$scope.$watch(() => {
            return this.appHeaderService.getPageInfo().title;
        }, (newVal, oldVal) => {

            this.title = this.appHeaderService.getPageInfo().title;

        }, true);
    }

    showHamburgerMenu() {
        this.OmniCfwDrawerService.showDrawer();
    }

}

angular
    .module('app')
    .controller('AppTitleBarController', AppTitleBarController);


