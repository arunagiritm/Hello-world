'use strict';


export class AppHeaderService {
    pageInfo = {
        title: null
    }

    getPageInfo() {
        return this.pageInfo;
    }
    setPageInfo(isBackEnabled, backAction, showOrganizationDashboard, title) {
        this.pageInfo.title = title;
    };
    setTitle(title) {
        this.pageInfo.title = title;
    };
}
