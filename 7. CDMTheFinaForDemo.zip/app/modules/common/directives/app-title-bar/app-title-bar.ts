import { APPEnums } from './../../../../config/services/app-enum';

const template:any = require('./app-title-bar.html');
AppTitleBar.$inject = ['APPEnums'];
export function AppTitleBar(APPEnums) {
    return {
        restrict: 'E',
        scope: {},
        // templateUrl: './app-title-bar.html',
        // template: require('./app-title-bar.html'),
        template,
        controller: AppTitleBarController,
    };
}
AppTitleBarController.$inject = ['$scope', 'OmniCfwDrawerService', 'AppHeader'];
export function AppTitleBarController($scope, OmniCfwDrawerService, AppHeader) {
    var UserModel;

    $scope.title = AppHeader.getPageInfo().title;

    $scope.showHamburgerMenu = function () {
        OmniCfwDrawerService.showDrawer();
    };
    $scope.$watch(function () {
        return AppHeader.getPageInfo().title;
    }, function (newVal, oldVal) {

        $scope.title = AppHeader.getPageInfo().title;

    }, true);
}