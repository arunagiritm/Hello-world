﻿const templateUrl:any = 'app/modules/common/directives/app-dialog/app-dialog.html';
AppDialog.$inject = ['AppDialogService'];
export function AppDialog(AppDialogService) {
    return {
        restrict: 'E',
        scope: {},
        templateUrl,
        // templateUrl: "app/modules/common/directives/app-dialog/app-dialog.html",
        link: function (s, e, a) {
            s.click = function (index) {
                AppDialogService.returnValue(index);
            }
            s.status = false;
            s.config = {};
            s.$watch(function () {
                return AppDialogService.getStatus();
            }, function (n, o) {
                s.status = n;
                if (n === true) {
                    s.config = AppDialogService.config;
                }
            }, true);
        }
    }
}

AppDialogService.$inject = ['$q'];
export function AppDialogService($q) {
    this.config = {};
    this.status = false;
    var defer = null;
    this.show = function (title, message, buttons) {
        defer = $q.defer();
        this.config = {};
        this.config.title = title;
        this.config.message = message;
        this.config.buttons = buttons;
        this.status = true;
        return defer.promise;
    };
    this.returnValue = function (btnIndex) {
        defer.resolve(btnIndex);
        this.status = false;
    };
    this.close = function () {
        if (defer)
            defer.reject();
        this.status = false;
    };
    this.getStatus = function () {
        return this.status;
    };
}


// app.directive('appDialog', AppDialog);
// app.service("AppDialogService", AppDialogService);