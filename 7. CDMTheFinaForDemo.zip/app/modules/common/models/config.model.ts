export interface ConfigModel {
    title: string;
    message: string;
    buttons: any;
}