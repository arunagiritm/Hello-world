﻿import * as angular from "angular";
import { APPEnums } from "../../../config/services/app-enum";
import { AppService } from "../../../config/services/app-service";

export class SessionModel {

    sessionData = {
        sessionCreated: false,
        sessionToken: '',
        ssgApplicationId: this.appEnums.ssgAppID,
        ssgSecurityToken: '',
        userProfile: null,
        challengeToken: null,
        platform: 'ios',
        timeout: null, // DEPRICATED PROPERTY
        fasToken: '',
        language: 'en-US',
        shortLanguageCode: 'en',
        regionCode: 'US',
        tlsId: '',
        isTermsAndConditionViewed: false,
        isLoggedIn: false
    }
    static $inject = ['$q', 'OmniCfwCommunicationService', 'APPEnums', 'AppService'];
    constructor(
        private $q: ng.IQService,
        private omniCfwCommunicationService,
        private appEnums: APPEnums,
        private appService: AppService
    ) { }

    getSessionData() {
        return this.sessionData;
    };
    setTLSID(tlsId) {
        this.sessionData.tlsId = tlsId;
    }
    getTLSID() {
        return this.sessionData.tlsId;
    };
    setTermsViewStatus(status) {
        this.sessionData.isTermsAndConditionViewed = status;
    };
    getTermsViewStatus() {
        return this.sessionData.isTermsAndConditionViewed;
    };
    createTLSID() {
        this.setTLSID(this.getRandomGuid());
    }

    setLanguage(language, shortLanguageCode) {
        if (!angular.isDefined(shortLanguageCode) && language.indexOf('-') > -1) {
            shortLanguageCode = language.split('-')[0];

        }
        this.sessionData.language = language;
        this.sessionData.shortLanguageCode = shortLanguageCode;

    };
    getLanguage() {
        return this.sessionData.language;
    };
    setPlatform(platform) {
        this.sessionData.platform = platform;
    };
    getPlatform() {
        return this.sessionData.platform;
    };
    setAuthToken(token) {
        this.sessionData.fasToken = token;
    };
    getAuthToken() {
        return this.sessionData.fasToken;
    };
    setSsgSecurityToken(ssgSecurityToken) {
        this.sessionData.ssgSecurityToken = ssgSecurityToken;
    };
    getSsgSecurityToken() {
        return this.sessionData.ssgSecurityToken;
    };
    setSessionToken(sessionToken) {
        this.sessionData.sessionToken = sessionToken;
    };
    getSessionToken() {
        return this.sessionData.sessionToken;
    };
    setRegion(regionCode) {
        this.sessionData.regionCode = regionCode;
    };
    getRegion() {
        return this.sessionData.regionCode;
    };
    getLanguageShortCode() {
        return this.sessionData.shortLanguageCode;
    };

    login() {
        this.sessionData.isLoggedIn = true;
    };
    isLoggedIn() {
        return this.sessionData.isLoggedIn;
    };
    getRandomNumber() {
        return Math.floor((Math.random() * 100000) + 1);
    };
    getRandomGuid() {
        let guidV4Format = "xxxxxxxx-xxxx-4xxx-yxxx-yxxxxxxxxxxx";
        let self = this;
        let section4Chars = ['a', 'b', '8', '9'];
        return guidV4Format.replace(/[xy]/g, function (c) {
            let random = self.getRandomNumber().toString(16).charAt(2);
            return c == 'x' ? random : section4Chars[Math.floor(Math.random() * section4Chars.length)];
        });
    };

    createAuthRequest(model) {
        let requestData=  {
            data: null,
            token: ''

        };

        if (this.sessionData.fasToken) {
            requestData.token = this.sessionData.fasToken;
        }
        // requestData.platform = "ios";
        //  requestData.languageId = "en-US";
        requestData.data = [];

        if (model.dynamicCode) {
            requestData.data.push({ "name": "otp", "value": model.dynamicCode });
        } else {
            if (model.password) {
                requestData.data.push({ "name": "password", "value": model.password });
            } else
                requestData.data.push({ "name": "auth-method", "value": "sms-otp" });
        }
        requestData.data.push({ "name": "alt-id", "value": model.userid });

        requestData.data.push({ "name": "action", "value": "submit" });
        return requestData;
    }
    create(data) {
        if (data) {
            this.sessionData.sessionCreated = true;
            this.sessionData.sessionToken = data.sessionToken || '';
            this.sessionData.fasToken = data.token || '';
            this.sessionData.ssgApplicationId = data.ssgApplicationId || '';
            this.sessionData.ssgSecurityToken = data.ssgSecurityToken || '';
            this.sessionData.userProfile = data;
        }
    }
    refresh(data) {
        if (data) {
            this.sessionData.sessionToken = data.sessionToken || this.sessionData.sessionToken;
            this.sessionData.ssgApplicationId = data.ssgApplicationId || this.sessionData.ssgApplicationId;
            this.sessionData.ssgSecurityToken = data.ssgSecurityToken || this.sessionData.ssgSecurityToken;
            this.sessionData.userProfile = data.userProfile || this.sessionData.userProfile;
            this.sessionData.fasToken = data.fasToken || this.sessionData.fasToken;
        }
    }
    logout() {
        this.sessionData.sessionCreated = null;
        this.sessionData.sessionToken = null;
        this.sessionData.fasToken = null;
        this.sessionData.ssgApplicationId = null;
        this.sessionData.ssgSecurityToken = null;
        this.sessionData.userProfile = null;
    }

}

