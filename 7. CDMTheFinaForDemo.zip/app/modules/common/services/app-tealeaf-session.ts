﻿import { AppUtils } from './app-utils';
import { APPEnums } from './../../../config/services/app-enum';
import * as angular from "angular";


export class AppTealeafSession {
    sessionID = null;
    static $inject = ['AppUtils'];
    constructor(private AppUtils) {

    }
    /*
        * A new Tealeaf session is created everytime user launches login screen
        */
    create() {
        this.sessionID = this.AppUtils.getRandomGuid();
        return this.sessionID;
    };

    /*
     * Public method to retrieve Tealeaf session id, created once per login
     */
    getSessionID() {
        return this.sessionID; //return tls id
    };

    /*
     * Destroys Tealeaf session ID during logout
     * 
     */
    destroy() {
        this.sessionID = null; // destroy Tealeaf session id 
    };

}


// angular.module('app').service('AppTealeafSession', AppTealeafSession);
