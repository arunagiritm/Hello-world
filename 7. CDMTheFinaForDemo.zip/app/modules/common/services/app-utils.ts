﻿import * as angular from "angular";
import * as _ from "lodash";
import { SessionModel } from './../models/session-model';
import { APPEnums } from './../../../config/services/app-enum';
import  "../../../../libs/encryption/encryption";


export class AppUtils {

    static $inject = ['cmbLocaliseService', 'SessionModel', 'Cmb'];
    constructor(private cmbLocaliseService, private SessionModel, private Cmb) {

    }
    getString(code) {
        return this.cmbLocaliseService.getResource(code, this.Cmb.UI.Localisation.CMM);
    };
    checkIfExistsInArray(array, value) {
        var result:{} = _.find(array, function (v) {
            if (v === value)
                return v;
        });
        if (angular.isDefined(result) && result !== null && result)
            return true;
        else
            return false;
    };

    encrypt(plainText) {
        var encryption = require('../../../../libs/encryption/encryption');
        var exponent = this.SessionModel.getExponent();
        var modulus = this.SessionModel.getModulus();
        var random = this.SessionModel.getRandom();
        // return encryption.encrypt(plainText, exponent, modulus, random);
    };
    /**
    * This function will return a random number.
    * @return {int} random number
    */
    getRandomNumber() {
        return Math.floor((Math.random() * 100000) + 1);
    };
    /*
    * This function returns a Random Guid, borrowed from CDT
    * @return {guid} xxxxxxxx-xxxx-4xxx-[ab89]xxx-xxxxxxxxxxxx
    * Truly relying on Math.random() might not be safe, 
    * however i already see an existing implementation of Math.random() hence following the same.
    * followed 128 bit guid pattern mentioned in https://en.wikipedia.org/wiki/Globally_unique_identifier#Text_encoding 
    */
    getRandomGuid() {
        var guidV4Format = "xxxxxxxx-xxxx-4xxx-yxxx-yxxxxxxxxxxx";
        var self = this;
        var section4Chars = ['a', 'b', '8', '9'];
        return guidV4Format.replace(/[xy]/g, function (c) {
            var random = self.getRandomNumber().toString(16).charAt(2);
            return c == 'x' ? random : section4Chars[Math.floor(Math.random() * section4Chars.length)];
        });
    };

    isObjectNull(obj) {
        if (_.isUndefined(obj)) return true;
        if (_.isNull(obj)) return true;

        return false;

    };

    getCurrentYear() {
        var currentDate = new Date();
        var year = currentDate.getFullYear();
        return year;
    };

    getCopyrightString() {
        var copyrightStr = this.getString('Global-CopyRight');
        var year = this.getCurrentYear();
        copyrightStr = copyrightStr.replace('{0}', year);
        return copyrightStr;
    };
}

// angular.module('app').service('AppUtils', AppUtils);
