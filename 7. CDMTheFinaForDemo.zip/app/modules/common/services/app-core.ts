﻿import * as angular from "angular";
import "../../../../libs/uifw/ngUIFW";


export class AppCore {

    language = "en";
    country = "US";
    languageCode = "en-US";
    Cmb;
    static $inject = [
        '$rootScope',
        'cmbLocaliseService',
        'OmniCfwCommunicationService',
        'HttpInteraction',
        'SessionModel',
        'OmniCfwNotification',
        'AppService',
        'OmniCfwCoreService',
        'AppLanguageCodes',
        '$q',
        '$window'


    ];
    constructor(
        private $rootScope,
        private cmbLocaliseService,
        private OmniCfwCommunicationService,
        private HttpInteraction,
        private SessionModel,
        private OmniCfwNotification,
        private AppService,
        private OmniCfwCoreService,
        private AppLanguageCodes,
        private $q,
        private $window

    ) {
        this.Cmb = this.$window.Cmb;
     }



    init(language) {

        let def = this.$q.defer();
        let locale = this.AppLanguageCodes.getClosestLanguage(language);
        let region = this.AppLanguageCodes.getRegion(language);
        this.SessionModel.setRegion(region);
        this.Cmb.UI.Localisation = this.Cmb.UI.Localisation || {};
        this.Cmb.UI.Localisation.CDM = this.Cmb.UI.Localisation.CDM || {};
        this.Cmb.UI.Localisation.CDM.locale = this.Cmb.UI.Localisation.CDM.locale || [];

        let lang = this.loadLanguage(locale);
        lang.then(() => {
            this.initHttpInteraction();
            this.initStateChangeEvent();
            def.resolve();
        }, function (reject) {
            def.reject(reject);
        });
        return def.promise;
    };


    loadLanguage = function (lang) {
        let defer = this.$q.defer();
        lang = 'en-US';
        this.OmniCfwCommunicationService.get('app/config/locale/' + lang + '.js').then((response) => {
            this.Cmb.UI.Localisation.CDM.locale[lang] = response.data;
            this.cmbLocaliseService.initialise(lang, this.Cmb.UI.Localisation.CDM);
            this.SessionModel.setLanguage(lang);
            defer.resolve(lang);
        }, function (reject) {
            defer.reject(reject);
        });
        return defer.promise;
    };

    initHttpInteraction = function () {
        this.HttpInteraction.config();
    };

    initStateChangeEvent = function () {
        this.$rootScope.$on('$stateChangeStart', function () {
            //OmniCfwNotification.clearAll();
        });
    };
}

// angular.module('app')
//     .service('AppCore', AppCore);