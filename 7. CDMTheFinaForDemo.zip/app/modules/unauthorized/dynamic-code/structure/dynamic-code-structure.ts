import { AppDynamicCode } from "../contents/app-dynamic-code";

 export function DynamicCodeStructure( ) {
         
}

