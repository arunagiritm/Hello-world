import { Notification } from './../../../../config/models/notification.model';

import { APPEnums } from './../../../../config/services/app-enum';
import * as angular from "angular";

const template: any = require('./app-dynamic-code.html');

 
export function AppDynamicCode():ng.IDirective {
    return {

        restrict:  'EA',
        scope:  true,
        template,
        // template:  require('./app-login.html'),
        controller:  'AppDynamicCodeController',
        controllerAs:  'dynamicCodeCtrl'
    }
}

// export function AppDynamicCode():ng.IDirective {
//     return {
//         restrict: 'EA',
//         scope: true,
//         // template,
//         // templateUrl: './app-dynamic-code.html' ,
//         // controller: 'AppDynamicCodeController',
//         controllerAs: 'dynamicCodeCtrl'
//     };
// }
// AppDynamicCode.$inject = ['APPEnums'];


AppDynamicCodeController.$inject = [
    '$scope', 
    '$stateParams', 
    'OmniCfwCommunicationService', 
    'OmniCfwNotification', 
    'OmniCfwDeviceService', 
    'cmbLocaliseService', 
    'SessionModel', 
    'OmniCfwSpinnerService', 
    'AppDeviceService', 
    'APPEnums', 
    '$state',
    '$window'
    ];

export function AppDynamicCodeController(
    $scope,
    $stateParams,
    OmniCfwCommunicationService,
    OmniCfwNotification,
    OmniCfwDeviceService,
    cmbLocaliseService,
    SessionModel,
    OmniCfwSpinnerService,
    AppDeviceService,
    APPEnums,
    $state,
    $window
) {
    let Cmb = $window.Cmb;
    var dynamicCodeCtrl = this;
    dynamicCodeCtrl.dictionary = Cmb.UI.Localisation.CDM;
    OmniCfwNotification.clearAll();

    var notification: Notification = <Notification>{};
    notification.title = 'Error';
    notification.isError = true;

    dynamicCodeCtrl.showLoading = false;
    OmniCfwSpinnerService.hide(true);

    dynamicCodeCtrl.dynamicCode = '';
    dynamicCodeCtrl.getResource = function (key) {
        return cmbLocaliseService.getResource(key, this.dictionary);
    };
    dynamicCodeCtrl.smsStatus = 'OTP-TRY-AGAIN';
    dynamicCodeCtrl.callStatus = 'OTP-OPTION-CALL';
    dynamicCodeCtrl.requestedDynamicCode = true;

    dynamicCodeCtrl.resetToLogin = function () {
        AppDeviceService.closeKeyboard();
        $state.go(APPEnums.CDM_STATES.LOGIN);
    };

    dynamicCodeCtrl.requestViaSMS = function () {
        dynamicCodeCtrl.callStatus = 'OTP-OPTION-CALL';
        dynamicCodeCtrl.smsStatus = 'OTP-TRY-AGAIN';
        dynamicCodeCtrl.requestedDynamicCode = true;
    }
    dynamicCodeCtrl.requestViaCall = function () {
        dynamicCodeCtrl.callStatus = 'OTP-TRY-AGAIN';
        dynamicCodeCtrl.smsStatus = 'OTP-OPTION-SMS';
        dynamicCodeCtrl.requestedDynamicCode = true;
    }
    dynamicCodeCtrl.submitDynamicCode = function () {
        AppDeviceService.closeKeyboard();
        dynamicCodeCtrl.formValid = dynamicCodeCtrl.validateDynamicCode();
        if (dynamicCodeCtrl.formValid) {
            dynamicCodeCtrl.showLoading = true;
            OmniCfwSpinnerService.show(true);
            var postData = {
                'userid': $stateParams.userid,
                'dynamicCode': dynamicCodeCtrl.dynamicCode
            };
            var requestJSON = SessionModel.createAuthRequest(postData);

            OmniCfwCommunicationService.post(APPEnums.getURL(APPEnums.SERVICE.LOGIN_DATA_URL),
                requestJSON).then(function (response) {
                    dynamicCodeCtrl.showLoading = false;
                    OmniCfwSpinnerService.hide(true);
                    if (response.status === 200) {
                        var data = response.data;
                        SessionModel.refresh({
                            sessionToken: response.headers('sessionToken'),
                            ssgSecurityToken: response.headers('securityToken'),
                            userProfile: data.user,
                            fasToken: data.token
                        });
                        $state.go(APPEnums.CDM_STATES.DASHBOARD);
                    }
                    else {
                        $scope.ifCodeError = true;

                        var errorMessage = dynamicCodeCtrl.getResource('Error-Login-Generic');
                        notification.content = errorMessage;
                        OmniCfwNotification.addNotification(notification);
                        dynamicCodeCtrl.resetToLogin();

                    }

                }, function (response) {
                    dynamicCodeCtrl.showLoading = false;
                    OmniCfwSpinnerService.hide(true);
                    $scope.ifCodeError = true;

                    var errorMessage = dynamicCodeCtrl.getResource('Error-Login-Generic');
                    notification.content = errorMessage;
                    OmniCfwNotification.addNotification(notification);
                    dynamicCodeCtrl.resetToLogin();

                });
        }
    };

    dynamicCodeCtrl.validateDynamicCode = function () {
        if (!dynamicCodeCtrl.dynamicCode) {
            notification.content = dynamicCodeCtrl.getResource('Error-DynamicCode-Empty');
            OmniCfwNotification.addNotification(notification);
            $scope.ifCodeError = true;
            return false;
        } else {
            $scope.ifCodeError = false;
            return true;
        }
    }

    dynamicCodeCtrl.clearError = function () {
        $scope.ifCodeError = false;
        OmniCfwNotification.clearAll();
    }
}

