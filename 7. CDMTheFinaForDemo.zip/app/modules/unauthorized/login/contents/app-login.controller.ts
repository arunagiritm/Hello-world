import { Notification } from './../../../../config/models/notification.model';
import { appSettings } from './../../../../config/settings/app-settings';
import { SessionModel } from './../../../common/models/session-model';
import { AppService } from './../../../../config/services/app-service';
import { APPEnums } from './../../../../config/services/app-enum';

import * as _ from "lodash";
import * as angular from "angular";

    export  class AppLoginController {
        password: string;
        dictionary;
        notification: Notification = {
            title: 'Error',
            isError: true,
            content: ''
        };
        termsTemplate;
        userid;
        ifUserError: boolean;
        showLoading: boolean;
        ifPassError: boolean;
      
        constructor(
            private $scope,
            private $sce,
            private $timeout,
            private $state,
            private $stateParams,
            private $cordovaSplashscreen,
            private OmniCfwNotification,
            private OmniCfwCommunicationService,
            private SessionModel,
            private AppService,
            private AppDeviceService,
            private OmniCfwDeviceService,
            private cmbLocaliseService,
            private OmniCfwSpinnerService,
            private AppDialogService,
            private $window,
            private appEnums: APPEnums
        ) {
            "ngInject";
            this.dictionary = this.$window.Cmb.UI.Localisation.CDM;
            this.OmniCfwSpinnerService.hide(true);
            this.termsTemplate = this.appEnums.TEMPLATE_URL.TERMS;
            if (!this.SessionModel.getTermsViewStatus()) {
                AppDialogService.show('title', this.termsTemplate, 'ok');
                localStorage.setItem(this.appEnums.RESOURSE_CONST.TERMS_ACCEPTED, 'true');
                SessionModel.setTermsViewStatus(true);
            }

            if (this.SessionModel.isLoggedIn()) {
                //SessionModel.logout();
            }

        }

        getResource(key) {
            return this.cmbLocaliseService.getResource(key, this.dictionary);
        };
        raiseErrorNotification(literalCode) {
            this.notification.content = this.getResource(literalCode);
            this.OmniCfwNotification.addNotification(this.notification);
        };

        checkUserId() {
            if (_.isEmpty(this.userid)) {
                this.raiseErrorNotification('Error-UsernameEmpty');
                this.ifUserError = true;
            } else {
                this.showLoading = true;
                this.OmniCfwSpinnerService.show(true);
                var postData = {
                    'userid': this.userid
                };
                var requestJSON = this.SessionModel.createAuthRequest(postData);
                this.OmniCfwCommunicationService.post(this.appEnums.getURL(this.appEnums.SERVICE.LOGIN_DATA_URL), requestJSON).then((response) => {
                    if (response.status === 202 || response.status === 200) {
                        var loginResData = response.data;
                        this.SessionModel.create(loginResData);
                        this.SessionModel.refresh({
                            sessionToken: response.headers('sessionToken'),
                            ssgSecurityToken: response.headers('securityToken'),
                            userProfile: loginResData.user,
                            fasToken: loginResData.token
                        });
                    }
                    this.showLoading = false;
                    this.OmniCfwSpinnerService.hide(true);

                }, (response) => {
                    this.showLoading = false;
                    this.OmniCfwSpinnerService.hide(true);
                });
            }
        }

        closeSplashScreen() {
            try {
                this.$cordovaSplashscreen.hide();//hide splashscreen upon opening login screen.
            } catch (error) { }
        }
        // closeSplashScreen();

        goToDynamicCodeSection() {
            if (this.validateLoginForm()) {
                this.showLoading = true;
                this.OmniCfwSpinnerService.show(true);
                var postData = {
                    'userid': this.userid,
                    'password': this.password
                }
                var requestJSON = this.SessionModel.createAuthRequest(postData);
                this.OmniCfwCommunicationService.post(this.appEnums.getURL(this.appEnums.SERVICE.LOGIN_DATA_URL), requestJSON).then(function (response) {


                    this.showLoading = false;
                    this.OmniCfwSpinnerService.hide(true);
                    if (response.status === 202 || response.status === 200) {
                        var loginResData = response.data;
                        this.SessionModel.refresh({
                            sessionToken: response.headers('sessionToken'),
                            ssgSecurityToken: response.headers('securityToken'),
                            userProfile: loginResData.user,
                            fasToken: loginResData.token
                        })
                    }
                    this.$state.go(this.appEnums.CDM_STATES.DYNAMICCODE, {
                        userid: this.userid
                    })

                }, (response) => {
                    this.showLoading = false;
                    this.OmniCfwSpinnerService.hide(true);
                    // if(response.status === 401){
                    this.$state.go(this.appEnums.CDM_STATES.DYNAMICCODE, {
                        userid: this.userid
                    })

                })
            }
        }


        validateLoginForm() {
            this.clearError();
            //_.isEmpty checks for null, undefined and empty value;
            if (_.isEmpty(this.userid) || _.isEmpty(this.password)) { //both username and password are empty
                if (_.isEmpty(this.userid) && _.isEmpty(this.password)) {
                    this.raiseErrorNotification('Error-UsernameEmpty');
                    this.ifUserError = true;
                    this.ifPassError = true;
                }
                else if (_.isEmpty(this.userid)) {
                    this.raiseErrorNotification('Error-UsernameEmpty');
                    this.ifUserError = true;
                }
                else {
                    this.raiseErrorNotification('Error-PasswordEmpty');
                    this.ifPassError = true;
                }
                return false;
            } else {
                this.ifUserError = false;
                this.ifPassError = false;
                return true;
            }
        };

        clearError() {
            this.ifUserError = false;
            this.ifPassError = false;
            this.OmniCfwNotification.clearAll();
        };
    }
  
