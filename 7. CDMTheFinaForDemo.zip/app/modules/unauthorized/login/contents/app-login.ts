// import { AppLoginController } from './app-login.controller';
import * as angular from "angular";


    const template: any = require('./app-login.html');

    export function AppLogin(): ng.IDirective {
        return {

            restrict: 'EA',
            scope: true,
            template,
            // template:  require('./app-login.html'),
            controller: 'AppLoginController',
            controllerAs: 'loginCtrl'
        }
    }






