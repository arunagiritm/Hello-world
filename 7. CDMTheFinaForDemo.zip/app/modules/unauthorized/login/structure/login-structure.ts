// import { AppLogin } from "../contents/app-login";

export function LoginStructure($scope) {

}

