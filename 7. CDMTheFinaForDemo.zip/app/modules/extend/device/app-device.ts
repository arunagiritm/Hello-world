
import * as angular from "angular";
import * as _ from "lodash";

declare var getCMAMTInfo;


AppDeviceDirective.$inject = ['$cordovaKeyboard', '$compile', 'AppDeviceService', '$cordovaDevice', '$window'];
export function AppDeviceDirective($cordovaKeyboard, $compile, AppDeviceService, $cordovaDevice, $window) {

    return {
        restrict: 'A',
        scope: {},
        controller: function () { },
        link: function (s, e, a) {
            try {
                $cordovaKeyboard.hideAccessoryBar(true);
                $cordovaKeyboard.disableScroll(true);
            } catch (error) { }

            AppDeviceService.setAvailableHeight($(window).height());

            var hideKeyboard = function () {
                if (e.srcElement.type) {
                    var t = e.srcElement.type;
                    if (!(t === 'text' || t === 'password' || t === 'number' || t === 'tel' || e.srcElement.type === 'search')) {
                        if (cordova.plugins) {
                            cordova.plugins.Keyboard.close();
                        }
                    }
                } else {
                    if (!($(e.srcElement).hasClass('ion-ios-close-outline')))
                        cordova.plugins.Keyboard.close();
                }
            };

            var onBackButtonClick = function (e) {
                e.preventDefault();
            };
            document.addEventListener('click touchstart', hideKeyboard, false);

            document.addEventListener('backbutton', onBackButtonClick, false);
            var platform = 'IOS';

            try {
                platform = $cordovaDevice.getPlatform();
                platform = platform.toUpperCase();
            } catch (error) { }

            var height = $(window).height();
            /*if (platform ==='IOS') {
                //create new styles to be used later
                //1. only header
                //2. with sub-header
                height -= 20;
            }

            height -= 44;//single header*/

            var createNewCss = function () {
                AppDeviceService.singleHeaderAvailableHeight = height;
                AppDeviceService.doubleHeaderAvailableHeight = height - 44;

                var style = document.createElement('style');
                style.type = 'text/css';
                style.innerHTML = '.single-header { height:' + AppDeviceService.singleHeaderAvailableHeight + 'px; }';
                style.innerHTML += '.double-header {height:' + AppDeviceService.doubleHeaderAvailableHeight + 'px}';
                document.getElementsByTagName('head')[0].appendChild(style);

            };
            height -= 44;//single header
            if (platform === 'IOS') {
                AppDeviceService.getDeviceInfo().then(function () {
                    var screenSize = AppDeviceService.getCMAMTInfo().ScreenSize.split('x');
                    var screenHeight = 0;
                    if (screenSize.length > 1) {
                        screenHeight = parseInt(screenSize[1], 10);
                        AppDeviceService.setAvailableHeight(screenHeight);
                        $window.actualHeight = screenHeight;
                    }
                    if (screenHeight > 0)
                        height = screenHeight;

                    try {
                        platform = $cordovaDevice.getPlatform();
                        platform = platform.toUpperCase();
                    } catch (error) { }

                    if (platform === 'IOS') {
                        //create new styles to be used later
                        //1. only header
                        //2. with sub-header
                        height -= 20;
                    }
                    createNewCss();
                }, function () {
                    $window.actualHeight = $(window).height();
                    createNewCss();
                });
            } else {
                //for non angular components to use height
                $window.actualHeight = $(window).height();
                createNewCss();
            }

            var bootstrapWatch = s.$watch(function () {
                return AppDeviceService.canBootstrap();
            }, function (n, o) {
                if (n === true) {
                    $('body').attr('omni-cfw-body', 'true');
                    $compile($('body'))(s);
                    bootstrapWatch();
                }
            });
            var FastClick: any = require('fastclick');
            FastClick.attach(document.body);
             //to remove 300ms click delay
        }
    }

}

AppDeviceService.$inject = ['$q', '$cordovaGlobalization', '$cordovaDialogs', '$cordovaDevice', '$cordovaKeyboard', '$window'];
export function AppDeviceService($q, $cordovaGlobalization, $cordovaDialogs, $cordovaDevice, $cordovaKeyboard, $window) {

    var self = this;
    this.canBootstrapOmniCfw = false;
    this.availableHeight = 0;
    this.singleHeaderAvailableHeight = 0;
    this.doubleHeaderAvailableHeight = 0;
    //Letiable casing is wrong, used the same as output of CMAMT
    this.CMAMTInfo = {
        Compromised: 0,
        DeviceModel: '',
        DeviceName: '',
        DeviceSystemName: '',
        DeviceSystemVersion: '',
        Emulator: 0,
        GeoLocationInfo: {
            Status: '0',
            Timestamp: ''
        },
        HardwareID: '',
        Languages: '',
        MCC: '',
        MNC: '',
        MultitaskingSupported: '',
        OS_ID: '',
        RSA_ApplicationKey: '',
        SDK_VERSION: '',
        ScreenSize: '',
        TIMESTAMP: ''
    };

    this.setAvailableHeight = function (height) {
        this.availableHeight = height;
    };

    this.getAvailableHeight = function () {
        return this.availableHeight;
    };

    this.bootstrap = function () {
        this.canBootstrapOmniCfw = true;
    };
    this.canBootstrap = function () {
        return this.canBootstrapOmniCfw;
    };
    this.validateThumbprint = function (server, thumbprint) {
        var defer = $q.defer();
        var success = function () {
            defer.resolve();
        };
        var fail = function () {
            defer.reject();
        };
        try {
            $window.plugins.sslCertificateChecker.check(
                success,
                fail,
                server,
                thumbprint
            );
        } catch (ee) {
            //In web mode
            success();
            //fail();
        };
        return defer.promise;
    };

    this.isDeviceValid = function () {
        //check to see if its simulator
        //check this from CMAMT
        return true;
    };
    this.isJailBroken = function () {
        if (angular.isDefined(self.CMAMTInfo.Compromised) && self.CMAMTInfo.Compromised == 1)
            return true;
        else
            return false;
    };

    this.isVersionValid = function () {
        return true;
    };
    this.isThumbPrintValid = function () {
        //check this from ssl certificate checker
        return true;
    };
    this.validateCountryRegulations = function (region) {
        if (region === 'SG') {
            return "Error-SGUsers";
        } else if (region === 'MY' && this.isJailBroken()) {
            return "Error-MYJailbrokenUsers";
        } else {
            return "";
        }
    };
    this.alert = function (message, buttons) {
        var defer = $q.defer();
        try {
            $cordovaDialogs.alert(message, "CitiManager", buttons).then(function (btnIndex) {
                defer.resolve(btnIndex);
            });
        } catch (e) {
            alert(message);
            defer.resolve(0);
        }
        return defer.promise;
    };
    this.getDeviceInfo = function () {
        var defer = $q.defer();
        var success = function (response) {
            response = angular.fromJson(response);
            angular.extend(self.CMAMTInfo, response);
            defer.resolve(response);
        };
        var fail = function (failure) {
            defer.reject();
        };
        try {
            // CMAMT.getInfo(success, fail);
        } catch (e) {
            success({});
        }
        return defer.promise;
    };
    this.extendCMAMT = function (e) {
        angular.extend(self.CMAMTInfo, {
            isMock: true
        });
        if (_.isString(e)) {
            self.CMAMTInfo.exception = e;
        }
        else {
            self.CMAMTInfo.exception = {};
            angular.extend(self.CMAMTInfo.exception, e);
        }
    };
    this.canContinue = function () {
        var defer = $q.defer();
        var success = function (response) {
            response = angular.fromJson(response);
            angular.extend(self.CMAMTInfo, response);
            defer.resolve(response);
        };
        var fail = function (failure) {
            self.extendCMAMT(failure);
            success({});
        };
        try {
            CMAMT.getInfo(success, fail);
        } catch (e) {
            self.extendCMAMT(e.message);
            success({});
        }
        return defer.promise;

    };
    this.getLangWithLocale = function (langs) {
        for (var i = 0; i < langs.length; i++) {
            if (langs[i].split("-").length > 1) {
                return langs[i];
            }
        }
        return 'en-US';
    }
    this.getLanguage = function () {
        var def = $q.defer();
        var self = this;
        try {
            $cordovaGlobalization.getLocaleName().then(function (language) {
                def.resolve(language.value);
            }, function (error) {
                def.resolve('en-US');
            });
        } catch (error) {
            try {
                var userPrefLanguage = navigator.languages ? self.getLangWithLocale(navigator.languages) : (navigator.language || navigator.userLanguage);
                def.resolve(userPrefLanguage);
            } catch (error) {
                def.resolve('en-US');
            }
        }
        return def.promise;
    };

    this.getDeviceData = function () {

        var deviceData: {
            platform: string,
            version: string,
            model: string,
            uuid: string
        };
        try {
            var data = getCMAMTInfo();
            deviceData.platform = data.DeviceSystemName;//'Android';
            deviceData.version = data.DeviceSystemVersion;//'5.0.2';
            deviceData.model = data.DeviceModel;//'Mi 4i';
            deviceData.uuid = data.HardwareID;//'123456789';

        } catch (error) {
            deviceData.platform = 'Android';
            deviceData.version = '5.0.2';
            deviceData.model = 'Mi 4i';
            deviceData.uuid = '123456789';
        }

        return deviceData;

    };
    this.getAppVersion = function () {
        var def = $q.defer();
        try {
            cordova.getAppVersion.getVersionNumber().then(function (version) {
                def.resolve(version);
            });

        } catch (error) {
            def.resolve('1.0');
        }
        return def.promise;
    };
    this.getCMAMTInfo = function () {
        return self.CMAMTInfo;
    };

    this.closeKeyboard = function () {
        try {
            $cordovaKeyboard.close();
        } catch (ex) { };
    };
}


angular.module('app.device', ['ngCordova'])
    .directive('appDevice', AppDeviceDirective)
    .service('AppDeviceService', AppDeviceService);

