import * as angular from "angular";
import * as _ from "lodash";


export function omniCfwTextboxDirective($delegate, $timeout) {

    var inputDelegate = $delegate[0];
    inputDelegate.scope = true;
    inputDelegate.require = ['?ngModel'];

    inputDelegate.template = function () {
        return '<div style="position: relative">' +
            '<span></span>' +
            '<input class="form-control"/>' +
            '<span ng-if="clear" class="ion ion-ios-close-outline clear-text" ng-class="{\'show\':!clearModel, \'hide\':clearModel}" ng-click="clearText()"></span>' +
            '</div>';
    };

    inputDelegate.compile = function (element, attrs) {
        var input = element.find('input');

        angular.forEach(attrs.$attr, function (value, name) {
            if (angular.isDefined(attrs[name])) {
                if (value === 'icon-class') {
                    input[0].style.paddingLeft = '50px';
                    element.find('span')[0].className = attrs[name];
                } else {
                    input[0].setAttribute(value, attrs[name]);
                }
            }
        });

        return {
            post: link
        };
    };

    function link(scope, element, attrs, ctrls) {
        var ngModelCtrl = ctrls[0];
        var input = $(element.find('input'));
        input.on('paste', function (ev) { ev.preventDefault() });

        scope.clearModel = true;
        scope.clear = (attrs.clear && attrs.clear === 'true') ? true : false;

        if (ngModelCtrl) {
            ngModelCtrl.$render = function () {
                var value = ngModelCtrl.$viewValue;
                if (!angular.isDefined(value)) {
                    return;
                }

                if (_.isUndefined(value) && _.isEmpty(document.activeElement)) {
                    scope.clearModel = false;
                } else if (_.isNull(value)) {
                    scope.clearModel = true;
                } else if (value.toString().length > 0) {
                    scope.clearModel = false;
                } else {
                    scope.clearModel = true;
                }


            };
        }

        scope.clearText = function () {
            if (ngModelCtrl) {
                ngModelCtrl.$setViewValue('');
                scope.clearModel = true;
                element.find('input').focus();
            }
        };
    }

    return $delegate;
}

export function omniCfwActionButtonDirective($delegate) {
    var buttonDelegate = $delegate[0];

    function link(scope, element) {
        function createRipple(evt) {
            var ripple = angular.element('<span class="ripple-effect animate">'),
                rect = element[0].getBoundingClientRect(),
                radius = Math.max(rect.height, rect.width),
                left = evt.pageX - rect.left - radius / 2 - document.body.scrollLeft,
                top = evt.pageY - rect.top - radius / 2 - document.body.scrollTop;
            ripple[0].style.width = ripple[0].style.height = radius + 'px';
            ripple[0].style.left = left + 'px';
            ripple[0].style.top = top + 'px';
            element.append(ripple);
        }

        element.on('click', createRipple);
    }

    buttonDelegate.template = function () {
        var template;
        template = '<button class="omni-cfw-action-button btn ripple-light{{class}}" ' +
            'ng-class="{{isDisabled===true}}?disabled:\'\'" ' +
            '  ng-click="buttonClicked($event)" ng-disabled="isDisabled" >' +
            '  <i class="{{iconClass}}"></i>{{label}}</button>';
        return template;
    };

    buttonDelegate.compile = function () {
        return {
            post: link
        };
    };

    return $delegate;
}

export function omniCfwMenuDirective($delegate) {
    $delegate[0].templateUrl = 'app/modules/extend/omnicfw/templates/app-menu-wrapper.html';
    return $delegate;
}

export function config($provide) {
    $provide.decorator('$state', function ($delegate, $rootScope) {
        $rootScope.$on('$stateChangeStart', function (event, state, params, fromState) {
            $delegate.next = state;
            $delegate.toParams = params;
            $delegate.fromState = fromState;
        });
        return $delegate;
    });
}

export let omnicfw = angular.module('app.omnicfw', [])
    .config(config)
    .decorator('omniCfwTextboxDirective', omniCfwTextboxDirective)
    .decorator('omniCfwActionButtonDirective', omniCfwActionButtonDirective)
    .decorator('omniCfwMenuDirective', omniCfwMenuDirective);