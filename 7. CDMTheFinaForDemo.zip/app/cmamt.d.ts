interface CmamtPlugin{
    getInfo(successCallback:Function, errorCallback:Function)
}
declare var CMAMT:CmamtPlugin;