export const appRoutes =
    Object.freeze([{
        state: 'login',
        url: '/login',
        templates: {
            phone: "app/modules/unauthorized/login/structure/login-structure.html",
            tablet: "app/modules/unauthorized/login/structure/login-structure.html",
            desktop: "app/modules/unauthorized/login/structure/login-structure.html"
        },
        title: 'Login',
        controllerName: 'LoginStructure',
        controllerPath: {
            phone: "app/modules/unauthorized/login/structure/login-structure",
            tablet: "app/modules/unauthorized/login/structure/login-structure",
            desktop: "app/modules/unauthorized/login/structure/login-structure"
        }, params: {
            errorCode: null
        },
        resolve: {
            appState: function (SessionModel, APPEnums) {
                var isTermsAndConditionViewed = localStorage.getItem(APPEnums.RESOURSE_CONST.TERMS_ACCEPTED);
                SessionModel.setTermsViewStatus(!!isTermsAndConditionViewed);
            },
            titleHeader: function (AppHeader) {
                /*  if (appSettings.tealeafAnalyticsEnabled) {
                      sessionModel.createTLSID();
                  }*/
                return AppHeader.setTitle(null);
            }
        }

    },
    {
        state: 'dynamicCode',
        url: '/dynamicCode',
        params: {
            userid: null
        },
        templates: {
            phone: "app/modules/unauthorized/dynamic-code/structure/dynamic-code-structure.html",
            tablet: "app/modules/unauthorized/dynamic-code/structure/dynamic-code-structure.html",
            desktop: "app/modules/unauthorized/dynamic-code/structure/dynamic-code-structure.html"
        },
        title: 'Dynamic Code',
        controllerName: 'DynamicCodeStructure',
        controllerPath: {
            phone: "app/modules/unauthorized/dynamic-code/structure/dynamic-code-structure",
            tablet: "app/modules/unauthorized/dynamic-code/structure/dynamic-code-structure",
            desktop: "app/modules/unauthorized/dynamic-code/structure/dynamic-code-structure"
        }
    },
        ,
    {
        state: 'dashboard',
        url: '/dashboard',
        templates: {
            phone: "app/modules/authorized/dashboard/structure/dashboard-structure.html",
            tablet: "app/modules/authorized/dashboard/structure/dashboard-structure.html",
            desktop: "app/modules/authorized/dashboard/structure/dashboard-structure.html"
        },
        title: 'Dashboard',
        controllerName: 'DashboardStructure',
        controllerPath: {
            phone: "app/modules/authorized/dashboard/structure/dashboard-structure",
            tablet: "app/modules/authorized/dashboard/structure/dashboard-structure",
            desktop: "app/modules/authorized/dashboard/structure/dashboard-structure"
        },
        resolve: {
            titleHeader: function (AppHeader) {
                return AppHeader.setTitle('Payments');
            }
        }
    }
    ]);