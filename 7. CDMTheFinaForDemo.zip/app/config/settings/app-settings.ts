﻿export const appSettings =
     Object.freeze({
        restBaseUrl: '',
        thumbprintCheckUrl: 'https://10.42.144.68:1292/api/v1.0/authentication/init',
        thumbprint: '38 aa 5a 4e 36 d0 4e b3 31 3f 9b 3a 9c ac b9 0f 60 28 89 41',
        appVersion: '1.0',
        ssgAppID: 'citimanager_mobile',
        useMockJson: true,
        omnicfwConfig: {
            use: false,
            device: 'phone',
            os: 'android',
            environment: 'web'
        }
    });