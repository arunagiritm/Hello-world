﻿export const mock = Object.freeze({
    use: false,
    device: 'phone',
    os: 'android',
    environment: 'app'
})
