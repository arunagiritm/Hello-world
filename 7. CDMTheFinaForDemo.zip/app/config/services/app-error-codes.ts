﻿import * as angular from "angular";
import * as _ from "lodash";

declare var Cmb;

export class AppErrorCodes {
    
    static inject = ['cmbLocaliseService'];
    constructor(private cmbLocaliseService) {
    

    }
    CMM_ERROR_CODES = Object.freeze([
        {
            statusCode: 99999,
            statusDescription: "Generic Exception",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 1,
            statusDescription: "System Exception",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 2,
            statusDescription: "Invalid Request",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 3,
            statusDescription: "Authentication Exception",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 4,
            statusDescription: "Authorization Exception",
            statusLocale: "Error-Generic",
            action: "notify"

        },
        {
            statusCode: 5,
            statusDescription: "Internal Exception",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 6,
            statusDescription: "Internal Exception",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 7,
            statusDescription: "No Data Available",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 200,
            statusDescription: "Login Failed. Account is inactive.",
            statusLocale: "Login-Error200",
            action: "notify"
        },
        {
            statusCode: 201,
            statusDescription: "Password Expired.",
            statusLocale: "Login-Error201",
            action: "notify"
        },
        {
            statusCode: 202,
            statusDescription: "Grace Period. Password has expired, but, User’s account is in the Grace Period",
            statusLocale: "Login-Error202",
            action: "notify"
        },
        {
            statusCode: 204,
            statusDescription: "First Time Login",
            statusLocale: "Login-Error204",
            action: "notify"
        },
        {
            statusCode: 205,
            statusDescription: "Wrong Credentials",
            statusLocale: "Login-Error205",
            action: "notify"

        },
        {
            statusCode: 206,
            statusDescription: "Challenge Questions have not been set.",
            statusLocale: "Login-Error200",
            action: "notify"
        },
        {
            statusCode: 207,
            statusDescription: "User account successfully registered, but, Email, Zip have not been verified ",
            statusLocale: "Login-Error200",
            action: "notify"
        },
        {
            statusCode: 208,
            statusDescription: "User account has not been successfully registered, and, Email, Zip have not been verified",
            statusLocale: "Login-Error200",
            action: "notify"
        },
        {
            statusCode: 209,
            statusDescription: "Password has expired, Grace Period has expired, and, Email, Zip have not been verified",
            statusLocale: "Login-Error209",
            action: "notify"
        },
        {
            statusCode: 210,
            statusDescription: "Password has expired, Grace Period has not expired, and, Email, Zip have not been verified",
            statusLocale: "Login-Error210",
            action: "notify"
        },
        {
            statusCode: 211,
            statusDescription: "User does not have a CardHolder role in any of his associated companies.",
            statusLocale: "Login-Error211",
            action: "notify"
        },
        {
            statusCode: 212,
            statusDescription: "None of the User's Companies have been enabled for Mobile access.",
            statusLocale: "Login-Error212",
            action: "notify"

        },
        {
            statusCode: 213,
            statusDescription: "Invalid Login attempts exceeds the limit",
            statusLocale: "Login-Error213",
            action: "notify"
        },
        {
            statusCode: 300,
            statusDescription: "Cyota Registration Locked ",
            statusLocale: "Global-Error300",
            action: "notify"
        },
        {
            statusCode: 301,
            statusDescription: "Cyota System Unavailable",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 302,
            statusDescription: "Number of Challenge Question requests exceeds threshold",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 400,
            statusDescription: "Challenge Answer does not match the Challenge Question ",
            statusLocale: "Login-Error205",
            action: "notify"
        },
        {
            statusCode: 401,
            statusDescription: "Cyota Registration Locked",
            statusLocale: "Global-Error300",
            action: "notify"
        },
        {
            statusCode: 402,
            statusDescription: "After the Cyota was success during the forgot username flow and the email id is null or if there is any issue in sending the user name email.",
            statusLocale: "Login-Error402",
            action: "notify"
        },
        {
            statusCode: 500,
            statusDescription: "No Cards Available",
            statusLocale: "Global-Error500",
            action: "notify"

        },
        {
            statusCode: 1100,
            statusDescription: "Statement Start Date is greater than the Statement End Date",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 1101,
            statusDescription: "Invalid Currency Code",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 1200,
            statusDescription: "Invalid Currency Code",
            statusLocale: "",
            action: "notify"
        },
        {
            statusCode: 1300,
            statusDescription: "No accounts available for bill pay.",
            statusLocale: "Global-Error1300",
            action: "notify"

        },
        {
            statusCode: 1400,
            statusDescription: "Invalid Account Id",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 1401,
            statusDescription: "Double payment submitted in less than the configured time",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 1402,
            statusDescription: "The submitted payment exceeds the allowable total payment amount",
            statusLocale: "Global-Error1300",
            action: "notify"
        },
        {
            statusCode: 1500,
            statusDescription: "Error in log out",
            statusLocale: "Error-Generic",
            action: "notify"

        },
        {
            statusCode: 1600,
            statusDescription: "Contact information was not found",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 1700,
            statusDescription: "Double payment submitted in less than the configured time",
            statusLocale: "Global-Error1700",
            action: "notify"
        },
        {
            statusCode: 1800,
            statusDescription: "When the User name/last six digits of the account number is wrong for more than <Configured> times",
            statusLocale: "Global-Error1800",
            action: "notify"
        },
        {
            statusCode: 1801,
            statusDescription: "When the User name/last six digits of the account number doesn’t match our records.",
            statusLocale: "Global-Error1801",
            action: "notify"
        },
        {
            statusCode: 1802,
            statusDescription: "When the password is locked",
            statusLocale: "Global-Error1802",
            action: "notify"

        },
        {
            statusCode: 1803,
            statusDescription: "When the password is locked",
            statusLocale: "Global-Error1803",
            action: "notify"

        },
        {
            statusCode: 1804,
            statusDescription: "When the user base company is not Mobile Enabled.",
            statusLocale: "Global-Error1804",
            action: "notify"
        },
        {
            statusCode: 1805,
            statusDescription: "When the user base company is not Mobile Enabled.",
            statusLocale: "Global-Error1805",
            action: "notify"
        },
        {
            statusCode: 1900,
            statusDescription: "Please select a different password as this password has been used earlier.",
            statusLocale: "Global-Error1900",
            action: "notify"
        },
        {
            statusCode: 1901,
            statusDescription: "Please select a different password as this password has been used earlier.",
            statusLocale: "Global-Error1901",
            action: "notify"
        },
        {
            statusCode: 1904,
            statusDescription: "At least one letter is needed in New password.",
            statusLocale: "Global-Error1904",
            action: "notify"
        },
        {
            statusCode: 1905,
            statusDescription: "At least one uppercase letter is required in New password.",
            statusLocale: "Global-Error1905",
            action: "notify"
        },
        {
            statusCode: 1906,
            statusDescription: "At least one lowercase letter is required in New Password.",
            statusLocale: "Global-Error1906",
            action: "notify"
        },
        {
            statusCode: 1907,
            statusDescription: "At least one number is needed in New Password.",
            statusLocale: "Global-Error1907",
            action: "notify"

        },
        {
            statusCode: 1908,
            statusDescription: "At least one letter or number is required in New Password.",
            statusLocale: "Global-Error1908",
            action: "notify"
        },
        {
            statusCode: 1910,
            statusDescription: "Leading space is not allowed in New Password.",
            statusLocale: "Global-Error1910",
            action: "notify"
        },
        {
            statusCode: 1911,
            statusDescription: "Trailing space is not allowed in New password.",
            statusLocale: "Global-Error1911",
            action: "notify"
        },
        {
            statusCode: 1912,
            statusDescription: "Username and New password cannot be same.",
            statusLocale: "Global-Error1912",
            action: "notify"

        },
        {
            statusCode: 1915,
            statusDescription: "The current password is incorrect.",
            statusLocale: "Global-Error1915",
            action: "notify"
        },
        {
            statusCode: 1916,
            statusDescription: "Character(s) entered in New Password is/are not allowed.",
            statusLocale: "Global-Error1916",
            action: "notify"
        },
        {
            statusCode: 2002,
            statusDescription: "When the user is other than card holder or having other roles along with Card Holder and provides the user name and the account number",
            statusLocale: "Login-Error2002",
            action: "notify"

        },
        {
            statusCode: 2003,
            statusDescription: "When the user card is inactive",
            statusLocale: "Login-Error2003",
            action: "notify"
        },
        {
            statusCode: 2004,
            statusDescription: "When the invalid attempt is less than the configured value and the information provided is incorrect.",
            statusLocale: "Login-Error2004",
            action: "notify"
        },
        {
            statusCode: 2006,
            statusDescription: "When the user base company is not Mobile Enabled. .",
            statusLocale: "Login-Error2006",
            action: "notify"
        },
        {
            statusCode: 2100,
            statusDescription: "No payments applied to this account.",
            statusLocale: "Global-Error2100",
            action: "notify"
        },
        {
            statusCode: 2101,
            statusDescription: "Invalid Payment Period.",
            statusLocale: "Global-Error2002",
            action: "notify"
        },
        {
            statusCode: 2102,
            statusDescription: "The service is designed to support payment transactions for n days, but we are need to keep the limitation to avoid performance issue while passing a high value..",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 2103,
            statusDescription: "Invalid Currency Code.",
            statusLocale: "Error-Generic",
            action: "notify"
        },
        {
            statusCode: 506,
            statusDescription: "No internet connection.",
            statusLocale: "Error-NoInternet",
            action: "notify"
        }
    ]);
   


    getErrorInfo(statusCode): any {

        let errorCode = _.find(this.CMM_ERROR_CODES, { statusCode: statusCode });
        if (!errorCode) {
            errorCode = _.find(this.CMM_ERROR_CODES, { statusCode: 99999 });
        }
        let translatedLiteral = this.cmbLocaliseService.getResource(errorCode.statusLocale, Cmb.UI.Localisation.CMM);
        if (_.isEmpty(translatedLiteral)) {
            translatedLiteral = {
                translatedErrorDesc: errorCode.statusDescription,
                statusCode: 99999,
                statusLocale: "Error-Generic"
            };
        }
        // errorCode.translatedErrorDesc = translatedLiteral; //ToDo

        return errorCode;
    }
}
// angular.module('app').service("AppErrorCodes",AppErrorCodes);

