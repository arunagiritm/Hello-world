import * as angular from "angular";
import { APPEnums } from "./app-enum";
import { appSettings } from "../settings/app-settings";

export class AppService {
    static inject = ['APPEnums'];
    constructor(private appEnums: APPEnums) { }
    getUrl(value) {
        var url = appSettings.useMockJson ? value.mock : (appSettings.restBaseUrl + 'v' + appSettings.appVersion + '/' + value.rest);
        return url;
    }
    
}

// angular.module("app").service('AppService', AppService);
