﻿import { Notification } from './../models/notification.model';
import { AppTealeafSession } from './../../modules/common/services/app-tealeaf-session';
import * as angular from "angular";
import * as _ from 'lodash';
import { SessionModel } from '../../modules/common/models/session-model';
import { AppService } from '../../config/services/app-service';
import { appSettings } from '../../config/settings/app-settings';
import { APPEnums } from '../../config/services/app-enum';
import { AppErrorCodes } from '../../config/services/app-error-codes';
import '../../../libs/omnicfw';


export class HttpInteraction {
    notification: Notification
    static $inject = [
        'SessionModel',
        'AppService',
        'APPEnums',
        'AppErrorCodes',
        '$state',
        'OmniCfwCommunicationInterceptorService',
        'OmniCfwNotification',
        'AppTealeafSession'
    ]
    constructor(
        private sessionModel: SessionModel,
        private appService: AppService,
        private aPPEnums: APPEnums,
        private appErrorCodes: AppErrorCodes,
        private $state,
        private omniCfwCommunicationInterceptorService,
        private omniCfwNotification,
        private appTealeafSession: AppTealeafSession

    ) {
        this.notification= <Notification>{};
    }
    config() {
        this.omniCfwCommunicationInterceptorService.interaction({
            'receiveResponse': this.receiveResponse.bind(this),
            'responseError':  this.responseError.bind(this),
            'beforeSend': this.beforeSend.bind(this),
            '503':  this.F503.bind(this),
            '506':  this.F506.bind(this)
        })
    }
    receiveResponse(response) {
        if (response.config.method === "POST") {
            this.sessionModel.setAuthToken(response.data.authToken);
            this.sessionModel.setSessionToken(response.data.sessionToken);
            $(".overlay").remove();
            $(".spinner").remove();
        } else {
            //TODO: this is a hack need to remove this 
            if (response.data.authToken) {
                this.sessionModel.setAuthToken(response.data.authToken);
                this.sessionModel.setSessionToken(response.data.sessionToken);
            }
        }
    }

    responseError(error) {
        let statusCode = '';
        if (!_.isEmpty(error.data)) {
            if (!_.isUndefined(error.data.status))
                statusCode = error.data.status;
            else
                statusCode = 'HTTP:' + error.status;;
        }
        else
            statusCode = '99999';

        $(".overlay").remove();
        $(".spinner").remove();

        let errorCode = this.appErrorCodes.getErrorInfo(statusCode);
        if (errorCode) {
            this.omniCfwNotification.clearAll();

            this.notification.content = errorCode.translatedErrorDesc;
            this.notification.isError = true;
            if (!_.isUndefined(errorCode.statusLocale) && errorCode.statusLocale == 'Error-Generic') {
                this.notification.content += ' (' + statusCode + ')';
            }
            //suppress errors for logout, primarily because CM throws error on logout for expired session ids
            if (!(error.config && error.config.url && error.config.url.toLowerCase().indexOf('logout') > -1))
                this.omniCfwNotification.addNotification(this.notification);
        }

        if (statusCode === '506' && this.$state.$current.self.state === 'login') {
            this.$state.go('errorPage', {
                errorCode: 'Error-NoInternet',
                showLogin: true
            });
        }

    }

    beforeSend(config) {

        let token = this.sessionModel.getAuthToken();
        let sessionToken = this.sessionModel.getSessionToken();

        if (appSettings.useMockJson) {
            config.method = 'GET';
        }
        if (!angular.isDefined(config.data))
            config.data = {};

        config.data.languageId = this.sessionModel.getLanguageShortCode();
        config.data.languageCode = this.sessionModel.getLanguageShortCode();//TODO:remove this after its changed
        if (config.method === "POST") {
            $("BODY").spin('large');
        }
        if (config.method === "POST" && token != null) {

            config.data.authToken = token;
            if (sessionToken != null) {
                config.data.sessionToken = sessionToken;
            }

        }

        config.headers = {
            'Content-Type': 'application/json; charset=utf-8',
            'ssgAppID': appSettings.ssgAppID,
            'TLSID': this.appTealeafSession.getSessionID()
        };

    }

    F503() {

        this.notification.content = '503: Service Unavailable.';//Localise
        this.notification.isError = true;
    }
    F506() {

        this.notification.content = 'No Internet connection.';//Localise
        this.notification.isError = true;
        this.omniCfwNotification.addNotification(this.notification);

        this.$state.go('errorPage', {
            'errorCode': 'Error-NoInternet'
        });
    }
}

