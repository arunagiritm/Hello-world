import { appSettings } from './../settings/app-settings';
import * as angular from "angular";


export class APPEnums {

       ssgAppID = 'citidirect_tablet';
        //BASE_URL = 'http://cdmweb2.nam.nsroot.net:1300/api/v7.9';
        TEMPLATE_URL = Object.freeze({
			"LOGIN" : "app/modules/unauthorized/login/contents/app-login.html",
			"DYNAMICPASSWORD": "app/modules/unauthorized/dynamic-code/contents/app-dynamic-code.html",
			"DASHBOARD": "app/modules/authorized/dashboard/contents/app-dashboard.html",
			"TITLE_BAR": "app/modules/common/directives/app-title-bar/app-title-bar.html",
			"MENU": "app/modules/common/directives/app-menu/app-menu.html",
			"TERMS": "app/modules/unauthorized/terms/contents/termsCondition.html"
		});
        
        CDM_REST_URL = Object.freeze({
           });

        SERVICE = Object.freeze({
           "LOGIN_DATA_URL": 'authentication/issuesecuritytoken'
        });
        
        CDM_STATES = Object.freeze({
			"LOGIN" : "login",
            "DYNAMICCODE": "dynamicCode",
            "DASHBOARD": "dashboard" 
        });

        ROUTES = Object.freeze({
            ERROR_PAGE: "errorPage"
        });
        RESOURSE_CONST = Object.freeze({
            TERMS_ACCEPTED : "termsAccepted",
        });
		
        getURL = function (value) {
            return appSettings.restBaseUrl + '/' + value;
        }
        
}


