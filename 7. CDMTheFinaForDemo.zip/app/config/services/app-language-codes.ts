﻿import * as angular from "angular";
import * as _ from "lodash";


export class AppLanguageCodes {

    
    languages = [
        {
            code: "cs",
            countries: "CZ",
            locale: "cs-CZ"
        },
        {
            code: "da",
            countries: "DK",
            locale: "da-DK"
        },
        {
            code: "de",
            countries: "DE",
            locale: "de-DE"
        },
        {
            code: "el",
            countries: "GR",
            locale: "el-GR"
        },
        {
            code: "en",
            countries: "US",
            locale: "en-US"
        },
        {
            code: "es",
            countries: [
                { code: "ES", locale: "es-ES" },
                { code: "LA", locale: "es-LA" }
            ]
        },
        {
            code: "fi",
            countries: "FI",
            locale: "fi-FI"
        },
        {
            code: "fr",
            countries: "FR",
            locale: "fr-FR"
        },
        {
            code: "hu",
            countries: "HU",
            locale: "hu-HU"
        },
        {
            code: "id",
            countries: "ID",
            locale: "id-ID"
        },
        {
            code: "it",
            countries: "IT",
            locale: "it-IT"
        },
        {
            code: "kk",
            countries: "KZ",
            locale: "kk-KZ"
        },
        {
            code: "nb",
            countries: "NO",
            locale: "nb-NO"
        },
        {
            code: "nl",
            countries: "NL",
            locale: "nl-NL"
        },
        {
            code: "pl",
            countries: "PL",
            locale: "pl-PL"
        },
        {
            code: "pt",
            countries: "BR",
            locale: "pt-BR"
        },
        {
            code: "ro",
            countries: "RO",
            locale: "ro-RO"
        },
        {
            code: "ru",
            countries: "RU",
            locale: "ru-RU"
        },
        {
            code: "sk",
            countries: "SK",
            locale: "sk-SK"
        },
        {
            code: "sv",
            countries: "SE",
            locale: "sv-SE"
        },
        {
            code: "th",
            countries: "TH",
            locale: "th-TH"
        },
        {
            code: "tr",
            countries: "TR",
            locale: "tr-TR"
        },
        {
            code: "uk",
            countries: "UR",
            locale: "uk-UR"
        },
        {
            code: "zh",
            countries: [
                { code: "CN", locale: "zh-CN" },
                { code: "TW", locale: "zh-TW" }
            ]
        }

    ];
    constructor() { }

    getRegion(deviceLanguage) {
        let regionCode = "";
        if (deviceLanguage.indexOf('-') > -1) {
            regionCode = deviceLanguage.split('-')[1];
        }
        else {
            regionCode = "US";
        }
    }
    getClosestLanguage(deviceLanguage) {
        let languageCode = "";
        let countryCode = "";
        let locale = "";

        if (deviceLanguage.indexOf('-') > 0) {
            languageCode = deviceLanguage.split('-')[0];
            countryCode = deviceLanguage.split('-')[1];
        } else {
            languageCode = "en";
            countryCode = "US";
        }

        let languageObject = _.find(this.languages, function (language) {
            if (language.code === languageCode) {
                return language;
            }
        });

        let languageCountry = "";
        if (!_.isEmpty(languageObject)) {
            if (_.isArray(languageObject.countries)) {
                let countryObject = _.find(languageObject.countries, function (country) {
                    if (country.code === countryCode)
                        return country;
                });

                if (_.isEmpty(countryObject))
                    locale = languageObject.countries[0].locale;//default to 1st one
                else
                    locale = countryObject.locale;
            } else {
                // locale = languageObject.locale; //ToDo
            }
        } else {
            locale = "en-US";//default
        }

        return locale;
    }

}

// angular.module('app').service("AppLanguageCodes",AppLanguageCodes);

