export interface Notification {
    content: string;
    isError: boolean;
    title?:string;

}