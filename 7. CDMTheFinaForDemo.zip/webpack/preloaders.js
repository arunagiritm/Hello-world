module.exports = [
      {
        test: /\.ts$/,
        loader: 'tslint'
      }
];
