var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var CopyWebpackPlugin = require('copy-webpack-plugin');
var BrowserSyncPlugin = require('browser-sync-webpack-plugin');

var argv = require('yargs').argv;

var plugins = [
    new HtmlWebpackPlugin({
        template: './index.html',
        inject: 'body',
        hash: true
    }),
    new webpack.ProvidePlugin({
        $: 'jquery',
        jQuery: 'jquery',
        'window.jQuery': 'jquery',
        'window.jquery': 'jquery'
    }),
    new CopyWebpackPlugin([
        { from: 'app/config/locale', to: 'app/config/locale' },
        { from: 'app/config/settings', to: 'app/config/settings' },
        { from: 'libs/omnicfw', to: 'libs/omnicfw' },
        { from: 'app/assets', to: 'app/assets' },
        { from: 'app/moc', to: 'app/moc' },
        { from: 'app/**/*.html' },
        { from: 'plugins', to: 'plugins' },
        { from: './cordova_plugins.js' },
        { from: './config.js' },
        { from: './cordova.js' }

    ]),
    new webpack.optimize.CommonsChunkPlugin({
        name: ['vendor', 'citi'],
        chunks: ['angular'],
        minChunks: Infinity

    }),
];
if (argv.mobile) {
    // plugins.push(
    //     new webpack.optimize.UglifyJsPlugin(
    //         {
    //             warning: false,
    //             mangle: true,
    //             comments: false
    //         }
    //     )
    // );
} else {
    plugins.push(
        new BrowserSyncPlugin({
            host: 'localhost',
            port: 8080,
            server: {
                baseDir: 'dist'
            },
            ui: false,
            online: false,
            notify: false
        })
    );

}
module.exports = {
    plugins: plugins
}