module.exports = [
    { test: /[\/]angular\.js$/, loader: "exports?angular" },

    { test: /\.ts(x?)$/, loader: 'ng-annotate-loader!awesome-typescript-loader!angular1-templateurl-loader' },
    {
        test: /\.js$/,
        exclude: [/node_modules/, /libs\\3rdparty/, /libs\\3rdparty/, /libs\\jasmine-2.5.2/, /libs\\omnicfw/, /libs\\uifw/],
        loader: 'angular1-templateurl-loader'
    },
    {
        test: /\.css$/,
        loader: 'style-loader!css-loader'
    },
    {
        test: /\.scss$/,
        loader: 'style!css!sass'
    }, {
        test: /\.html$/,
        exclude: /node_modules/,
        loader: 'raw'
    }, {
        test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        loader: 'url-loader?limit=10000&mimetype=application/font-woff'
    }, {
        test: /\.(ttf|eot|svg|jpe?g|gif|png)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        loader: 'file-loader'
    }

];
