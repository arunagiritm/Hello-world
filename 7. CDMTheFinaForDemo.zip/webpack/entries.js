var argv = require('yargs').argv;

var entry = {
    main: ['./app/app.ts'],
    vendor: [
        './libs/3rdparty/angular/angular',
        './libs/3rdparty/angular/angular-ui-router',
        './libs/3rdparty/angular/angular-animate',
        './libs/3rdparty/angular/ng-cordova',
        './libs/3rdparty/angular/ui-bootstrap-tpls',
        './libs/3rdparty/angular/angular-ui-tab-scroll',
        './libs/3rdparty/angular/angular-activity-monitor',
    ],
    citi: [
        './libs/omniCfw',
        './libs/uifw/UIFW',
        './libs/uifw/uifw.grid.package',
        './libs/uifw/ngUIFW',
        './libs/3rdparty/spin'
    ]
}

module.exports = {
    entry:entry
}