var loaders = require("./loaders");
var preloaders = require('./preloaders');
var entry = require('./entries').entry;
var plugins = require('./plugins').plugins;
var BrowserSyncPlugin = require('browser-sync-webpack-plugin');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var webpack = require('webpack');
var path = require('path');
var CopyWebpackPlugin = require('copy-webpack-plugin');
var argv = require('yargs').argv;

module.exports = {
    entry: entry,
    output: {
        filename: '[name].bundle.js',
        path: 'dist'
    },

    resolve: {
        root: [__dirname, './'],
        extensions: ['', '.ts', '.js', '.json'],
    },
    resolveLoader: {
        modulesDirectories: ["node_modules"]
    },
    devtool: (argv.mobile) ? 'source-map' : "inline-eval-cheap-source-map",
    plugins: plugins,
    module: {
        preloaders: (argv.mobile) ? preloaders : {},
        loaders: loaders
    },
    tslint: {
        emitErrors: true,
        failOnHint: true
    }
};
